<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'scsswordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'KLif+iZ]?JsG$D+rq2quT5O;|.>,Lwt*1FYH}RaxYm}Ha|%-]Vx[L%o$X0OLz)iW');
define('SECURE_AUTH_KEY',  ':{H|b7BEajZ`+Zk4^hMq8n;KwI%_U*-;izfY4U[Q*jks>Oz~AuUN-wR;F7Rmg$HS');
define('LOGGED_IN_KEY',    '%KA&j!dS?pdVM|~y6lKYk#hf8eZ(+_|aTY`/+rHMD,Z>qoU*yU)?!=) ~`*KYd}T');
define('NONCE_KEY',        'lw>[sly9&onY}@g!2ZQ]b`*VvL(*Xf;yLA7=cbx#v-.!u]+&ta`:fw(iFa#svUfR');
define('AUTH_SALT',        '8n/a/?+S5`+?n+,Q6aFU(<?8FXx(E=O<|oSm$YP?{wPkMUE^_uw^w0B2lH_j,~X-');
define('SECURE_AUTH_SALT', 'CCA^s{|wPWi}]bKS@#va+{{g^k$e*#[w!1tyI@]~jEpU.6z?=~%2`*H@#<e/#;J^');
define('LOGGED_IN_SALT',   'Aw(OqY[|R}99;0.v~X)^iKw+Nh=lG-@K;6dM/_H*|7Ag-V4CI80($0)MO|XihxV=');
define('NONCE_SALT',       '3j s~&?-U)VL$W+Psw$q=mL5Nza9lX6:-$;X__7{Mc/i6$Rx-X|`AQU52]K-M7L3');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
