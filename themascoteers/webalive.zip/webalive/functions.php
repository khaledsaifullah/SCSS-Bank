<?php
/**
 * Twenty Sixteen functions and definitions
 *
 * Set up the theme and provides some helper functions, which are used in the
 * theme as custom template tags. Others are attached to action and filter
 * hooks in WordPress to change core functionality.
 *
 * When using a child theme you can override certain functions (those wrapped
 * in a function_exists() call) by defining them first in your child theme's
 * functions.php file. The child theme's functions.php file is included before
 * the parent theme's file, so the child theme functions would be used.
 *
 * @link https://codex.wordpress.org/Theme_Development
 * @link https://codex.wordpress.org/Child_Themes
 *
 * Functions that are not pluggable (not wrapped in function_exists()) are
 * instead attached to a filter or action hook.
 *
 * For more information on hooks, actions, and filters,
 * {@link https://codex.wordpress.org/Plugin_API}
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

/**
 * Twenty Sixteen only works in WordPress 4.4 or later.
 */
if ( version_compare( $GLOBALS['wp_version'], '4.4-alpha', '<' ) ) {
	require get_template_directory() . '/inc/back-compat.php';
}

if ( ! function_exists( 'twentysixteen_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * Create your own twentysixteen_setup() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on Twenty Sixteen, use a find and replace
	 * to change 'twentysixteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'twentysixteen', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for custom logo.
	 *
	 *  @since Twenty Sixteen 1.2
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 240,
		'width'       => 240,
		'flex-height' => true,
	) );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 1200, 9999 );

	//add_image_size('game-list-thumb', 1170, 99999);

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'twentysixteen' ),
		'social'  => __( 'Social Links Menu', 'twentysixteen' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside',
		'image',
		'video',
		'quote',
		'link',
		'gallery',
		'status',
		'audio',
		'chat',
	) );

	/*
	 * This theme styles the visual editor to resemble the theme style,
	 * specifically font, colors, icons, and column width.
	 */
	add_editor_style( array( 'css/editor-style.css', twentysixteen_fonts_url() ) );

	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // twentysixteen_setup
add_action( 'after_setup_theme', 'twentysixteen_setup' );

/**
 * Sets the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'twentysixteen_content_width', 840 );
}
add_action( 'after_setup_theme', 'twentysixteen_content_width', 0 );

/**
 * Registers a widget area.
 *
 * @link https://developer.wordpress.org/reference/functions/register_sidebar/
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'twentysixteen' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 1', 'twentysixteen' ),
		'id'            => 'sidebar-2',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => __( 'Content Bottom 2', 'twentysixteen' ),
		'id'            => 'sidebar-3',
		'description'   => __( 'Appears at the bottom of the content on posts and pages.', 'twentysixteen' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'twentysixteen_widgets_init' );

if ( ! function_exists( 'twentysixteen_fonts_url' ) ) :
/**
 * Register Google fonts for Twenty Sixteen.
 *
 * Create your own twentysixteen_fonts_url() function to override in a child theme.
 *
 * @since Twenty Sixteen 1.0
 *
 * @return string Google fonts URL for the theme.
 */
function twentysixteen_fonts_url() {
	$fonts_url = '';
	$fonts     = array();
	$subsets   = 'latin,latin-ext';

	/* translators: If there are characters in your language that are not supported by Merriweather, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Merriweather font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Merriweather:400,700,900,400italic,700italic,900italic';
	}

	/* translators: If there are characters in your language that are not supported by Montserrat, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Montserrat font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Montserrat:400,700';
	}

	/* translators: If there are characters in your language that are not supported by Inconsolata, translate this to 'off'. Do not translate into your own language. */
	if ( 'off' !== _x( 'on', 'Inconsolata font: on or off', 'twentysixteen' ) ) {
		$fonts[] = 'Inconsolata:400';
	}

	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => urlencode( implode( '|', $fonts ) ),
			'subset' => urlencode( $subsets ),
		), 'https://fonts.googleapis.com/css' );
	}

	return $fonts_url;
}
endif;

/**
 * Handles JavaScript detection.
 *
 * Adds a `js` class to the root `<html>` element when JavaScript is detected.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_javascript_detection() {
	echo "<script>(function(html){html.className = html.className.replace(/\bno-js\b/,'js')})(document.documentElement);</script>\n";
}
add_action( 'wp_head', 'twentysixteen_javascript_detection', 0 );

/**
 * Enqueues scripts and styles.
 *
 * @since Twenty Sixteen 1.0
 */
function twentysixteen_scripts() {

	if(BOOTSTRAP):
		wp_enqueue_style('bootstrap.min', get_template_directory_uri() . '/additional-lib/bootstrap/3.3.6/css/bootstrap.min.css', array(), false, false);
		wp_enqueue_script('bootstrap.min', get_template_directory_uri() . '/additional-lib/bootstrap/3.3.6/js/bootstrap.min.js', array(), false, true);
	endif;
	
	if(BXSLIDER):
		wp_enqueue_style('bxslider.css', get_template_directory_uri() . '/additional-lib/jquery.bxslider/jquery.bxslider.css', array(), false, false);
		wp_enqueue_script('bxslider.min', get_template_directory_uri() . '/additional-lib/jquery.bxslider/jquery.bxslider.min.js', array(), false, true);
	endif;

	if(COLORBOX):
		wp_enqueue_style('colorbox.css', get_template_directory_uri() . '/additional-lib/colorbox/colorbox.css', array(), false, false);
		wp_enqueue_script('colorbox.min', get_template_directory_uri() . '/additional-lib/colorbox/jquery.colorbox-min.js', array(), false, true);
	endif;

	wp_enqueue_script('slimscroll.min', get_template_directory_uri() . '/additional-lib/scrollbar/jquery.slimscroll.min.js', array(), false, true);
	
	// Add custom fonts, used in the main stylesheet.
	wp_enqueue_style( 'twentysixteen-fonts', twentysixteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.4.1' );

	// Theme stylesheet.
	wp_enqueue_style( 'twentysixteen-style', get_stylesheet_uri() );

	// Load the Internet Explorer specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentysixteen-style' ), '20160412' );
	wp_style_add_data( 'twentysixteen-ie', 'conditional', 'lt IE 10' );

	// Load the Internet Explorer 8 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie8', get_template_directory_uri() . '/css/ie8.css', array( 'twentysixteen-style' ), '20160412' );
	wp_style_add_data( 'twentysixteen-ie8', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	wp_enqueue_style( 'twentysixteen-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'twentysixteen-style' ), '20160412' );
	wp_style_add_data( 'twentysixteen-ie7', 'conditional', 'lt IE 8' );

	// Load the html5 shiv.
	wp_enqueue_script( 'twentysixteen-html5', get_template_directory_uri() . '/js/html5.js', array(), '3.7.3' );
	wp_script_add_data( 'twentysixteen-html5', 'conditional', 'lt IE 9' );

	wp_enqueue_script( 'twentysixteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20160412', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	if ( is_singular() && wp_attachment_is_image() ) {
		wp_enqueue_script( 'twentysixteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20160412' );
	}

	wp_enqueue_script( 'twentysixteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20160412', true );

	wp_localize_script( 'twentysixteen-script', 'screenReaderText', array(
		'expand'   => __( 'expand child menu', 'twentysixteen' ),
		'collapse' => __( 'collapse child menu', 'twentysixteen' ),
	) );

	wp_enqueue_script('custom', get_template_directory_uri() . '/js/custom.js', array(), null, true);
}
add_action( 'wp_enqueue_scripts', 'twentysixteen_scripts' );

/**
 * Adds custom classes to the array of body classes.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $classes Classes for the body element.
 * @return array (Maybe) filtered body classes.
 */
function twentysixteen_body_classes( $classes ) {
	// Adds a class of custom-background-image to sites with a custom background image.
	if ( get_background_image() ) {
		$classes[] = 'custom-background-image';
	}

	// Adds a class of group-blog to sites with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of no-sidebar to sites without active sidebar.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	return $classes;
}
add_filter( 'body_class', 'twentysixteen_body_classes' );

/**
 * Converts a HEX value to RGB.
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $color The original color, in 3- or 6-digit hexadecimal form.
 * @return array Array containing RGB (red, green, and blue) values for the given
 *               HEX code, empty array otherwise.
 */
function twentysixteen_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
	} else if ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array( 'red' => $r, 'green' => $g, 'blue' => $b );
}

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for content images
 *
 * @since Twenty Sixteen 1.0
 *
 * @param string $sizes A source size value for use in a 'sizes' attribute.
 * @param array  $size  Image size. Accepts an array of width and height
 *                      values in pixels (in that order).
 * @return string A source size value for use in a content image 'sizes' attribute.
 */
function twentysixteen_content_image_sizes_attr( $sizes, $size ) {
	$width = $size[0];

	840 <= $width && $sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 62vw, 840px';

	if ( 'page' === get_post_type() ) {
		840 > $width && $sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
	} else {
		840 > $width && 600 <= $width && $sizes = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 61vw, (max-width: 1362px) 45vw, 600px';
		600 > $width && $sizes = '(max-width: ' . $width . 'px) 85vw, ' . $width . 'px';
	}

	return $sizes;
}
add_filter( 'wp_calculate_image_sizes', 'twentysixteen_content_image_sizes_attr', 10 , 2 );

/**
 * Add custom image sizes attribute to enhance responsive image functionality
 * for post thumbnails
 *
 * @since Twenty Sixteen 1.0
 *
 * @param array $attr Attributes for the image markup.
 * @param int   $attachment Image attachment ID.
 * @param array $size Registered image size or flat array of height and width dimensions.
 * @return string A source size value for use in a post thumbnail 'sizes' attribute.
 */
function twentysixteen_post_thumbnail_sizes_attr( $attr, $attachment, $size ) {
	if ( 'post-thumbnail' === $size ) {
		is_active_sidebar( 'sidebar-1' ) && $attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 984px) 60vw, (max-width: 1362px) 62vw, 840px';
		! is_active_sidebar( 'sidebar-1' ) && $attr['sizes'] = '(max-width: 709px) 85vw, (max-width: 909px) 67vw, (max-width: 1362px) 88vw, 1200px';
	}
	return $attr;
}
add_filter( 'wp_get_attachment_image_attributes', 'twentysixteen_post_thumbnail_sizes_attr', 10 , 3 );

/**
 * Modifies tag cloud widget arguments to have all tags in the widget same font size.
 *
 * @since Twenty Sixteen 1.1
 *
 * @param array $args Arguments for tag cloud widget.
 * @return array A new modified arguments.
 */
function twentysixteen_widget_tag_cloud_args( $args ) {
	$args['largest'] = 1;
	$args['smallest'] = 1;
	$args['unit'] = 'em';
	return $args;
}
add_filter( 'widget_tag_cloud_args', 'twentysixteen_widget_tag_cloud_args' );

// Webalive

add_filter('show_admin_bar', '__return_false');

//initialize at header
function init_header()
{
	?>
	<script type="text/javascript">
		ajax_url = '<?php echo admin_url( 'admin-ajax.php'); ?>';
		home_url = '<?php echo home_url(); ?>';
		directory_url = '<?php echo get_template_directory_uri(); ?>';
	</script>
	<?php
}

add_action('wp_head', 'init_header', 1);

// add a favicon to frontend & backend
function blog_favicon() {
	echo '<link rel="Shortcut Icon" type="image/x-icon" href="'.get_template_directory_uri().'/images/favicon.ico" />';
}
add_action('wp_head', 'blog_favicon');
add_action('admin_head', 'blog_favicon');
add_filter('login_headerurl', 'blog_favicon');

add_action('init', 'wa_add_init');
function wa_add_init()
{
	ob_start();
	add_rewrite_rule('(^_.+)/([^/]+)?', 'index.php?game_slug=$matches[1]&download_string=$matches[2]', 'top');
	flush_rewrite_rules();
}

add_filter( 'query_vars', 'query_vars_func');
function query_vars_func( $query_vars )
{
	$query_vars[] = 'game_slug';
	$query_vars[] = 'download_string';
	return $query_vars;
}

function getCategoryIdsByPartialSlug($partial_slug){
	global $wpdb;
	$sql = "SELECT * FROM ".$wpdb->prefix."terms term
			INNER JOIN ".$wpdb->prefix."term_taxonomy term_taxonomy ON term.term_id =  term_taxonomy.term_id
			WHERE term.slug LIKE '%".$partial_slug."%' AND taxonomy = 'category'
	";
	$results = $wpdb->get_results($sql);
	$category_ids = array();
	if(!empty($results)) {
		foreach ($results as $result) {
			$category_ids[] = $result->term_id;
		}
	}
	return $category_ids;
}

function getPostCount($category_ids = array()){

	if(!empty($category_ids)) {
		global $wpdb;
		$sql = "SELECT COUNT(*) AS total FROM " . $wpdb->prefix . "posts
	 			WHERE post_type='post' AND post_status = 'publish' 
	 			AND ID IN ( SELECT object_id FROM " . $wpdb->prefix . "term_relationships where term_taxonomy_id IN(" . implode(',', $category_ids) . "))
	 	";
		$results = $wpdb->get_row($sql);
		if(!empty($results)){
			return $results->total;
		}
	}else{
		return 0;
	}
}


function getGamePostsHtml($game_slug){
	$game_category = get_category_by_slug($game_slug);
	if(empty($game_category)) return '';

	$args = array(
		'posts_per_page'   => -1,
		'category'         => $game_category->term_id,
		'orderby'          => 'date',
		'order'            => 'DESC',
		'post_status'      => 'publish',
	);
	$posts_array = get_posts( $args );

	if(!empty($posts_array)) {
		?>

		<section class="dropple-news box-container">
			<div class="container">
				<h2 class="h2"><?php echo $game_category->cat_name; ?> news</h2>
				<div class="row">
					<div class="col-sm-6">
						<div class="inner-content right-padding" id="featured-blog-slider">

							<?php
							if (!empty($posts_array)) {
								foreach ($posts_array as $item) {
									?>
									<div class="item">
										<div class="images">
											<?php
											if (has_post_thumbnail($item->ID)) {
												$image = wp_get_attachment_image_src(get_post_thumbnail_id($item->ID), 'full');
												?>
												<a href="<?php echo get_permalink($item); ?>"><img
														class="img-responsive" src="<?php echo $image[0] ?>"
														alt="<?php echo $item->post_title; ?>"></a>
												<?php
											}
											?>
										</div>
										<div class="description-area">
											<h5>
												<a href="<?php echo get_permalink($item); ?>"><?php echo $item->post_title; ?></a>
											</h5>
											<div class="designation">
												<ul>
													<li>By <?php echo get_the_author(); ?></li>
													<li><a href="<?php echo get_term_link($game_category); ?>"><?php echo $game_category->name; ?></a></li>
												</ul>
											</div>
											<div class="intro-text">
												<p>
													<?php
													$content = apply_filters('the_content', $item->post_content);
													echo readMore($content, $word_limit = 30);
													?>
												</p>
											</div>
										</div>
									</div>
									<?php
								}
							}
							?>

						</div>

						<span id="slider-prev"></span>
						<span id="slider-next"></span>

					</div>

					<div class="col-sm-6">
						<div class="inner-content left-padding" id="blog-slider">

							<?php

							$args = array(
								'posts_per_page'   => -1,
								'category'         => $game_category->term_id,
								'orderby'          => 'date',
								'order'            => 'DESC',
								'post_status'      => 'publish',
							);

							$args['tax_query'] = array(
								array(
									'taxonomy' => 'post_tag',
									'field' => 'slug',
									'terms' => array('how-to-play', 'game-tips')
								)
							);

							$posts_array = get_posts( $args );

							if (!empty($posts_array)) {
								foreach ($posts_array as $item) {
									?>

									<div class="row gutter-10 post-id-<?php echo $item->ID ?>">
										<div class="col-sm-3">
											<div class="images">
												<?php
												if (has_post_thumbnail($item->ID)) {
													$image = wp_get_attachment_image_src(get_post_thumbnail_id($item->ID), 'full');
													?>
													<a href="<?php echo get_permalink($item); ?>"><img
															class="img-responsive" src="<?php echo $image[0] ?>"
															alt="<?php echo $item->post_title; ?>"></a>
													<?php
												}
												?>
											</div>
										</div>
										<div class="col-sm-9">
											<div class="new-desc">
												<h5>
													<a href="<?php echo get_permalink($item); ?>"><?php echo $item->post_title; ?></a>
												</h5>
												<div class="designation">
													<ul>
														<li>By <?php echo get_the_author(); ?></li>
														<li><a href="<?php echo get_term_link($game_category); ?>"><?php echo $game_category->name; ?></a></li>
													</ul>
												</div> <!-- designation -->
												<div class="intro-text">
													<?php
													$content = apply_filters('the_content', $item->post_content);
													echo readMore($content, $word_limit = 20);
													?>
												</div> <!-- intro-text -->
											</div>
										</div>
									</div>

									<?php
								}
							}

							?>
						</div>

					</div>
				</div>
			</div>
		</section>

		<?php
	}

}
function custom_login_logo() {
	?>
	<style type="text/css">
		body.login div#login h1 a {
			background-image: url("<?php echo get_template_directory_uri(); ?>/images/company-logo-home.png");
			background-size:100%;
			height: 88px;
			padding: 0;
			width: 81px;
		}
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'custom_login_logo');

function getGameLink($post_id){
	
	$game_id = get_post_meta($post_id, 'game_id', true );
	$link = '';
	if(!empty($game_id)){
		$game = get_post($game_id);
		$link = '<a href="'.get_permalink($game).'" class="dropple-link game-link">Go To '.get_the_title($game).' Page</a>';
	}

	return $link;
}


function readMore($content, $word_limit=50, $link = false){
	$content = strip_tags($content);
	$explode_content = explode(" ", $content);
	if(sizeof($explode_content)>$word_limit){
		$slice_content = array_slice($explode_content, 0, $word_limit);
		$content = implode(" ", $slice_content).'...';
		if($link){
			$content .=' <span class="read-more"><a href="'.get_permalink().'">Read more</a></span>';
		}
	}
	return $content;
}

function wp_get_all_tags( $args = '' ) {

	$tags = get_terms('post_tag');
	foreach ( $tags as $key => $tag ) {
		if ( 'edit' == 'view' )
			$link = get_edit_tag_link( $tag->term_id, 'post_tag' );
		else
			$link = get_term_link( intval($tag->term_id), 'post_tag' );
		if ( is_wp_error( $link ) )
			return false;

		$tags[ $key ]->link = $link;
		$tags[ $key ]->id = $tag->term_id;
		$tags[ $key ]->name = $tag->name;
//      echo ' <a href="'. $link .'">' . $tag->name . '</a>';
	}
	return $tags;
}

add_filter( 'get_the_archive_title', function ($title) {

	if ( is_category() ) {

		$title = single_cat_title( '', false );

	} elseif ( is_tag() ) {

		$title = single_tag_title( '', false );

	} elseif ( is_author() ) {

		$title = '<span class="vcard">' . get_the_author() . '</span>' ;

	}

	return $title;

});


function getTypeByURL($url){

	if(strstr($url, 'v=') || strpos($url, 'youtube.com') || strpos($url, 'youtu.be')){
		$type = 'youtube';
	}elseif(strpos($url, 'vimeo.com')){
		$type = 'vimeo';
	}
	return $type;
}

function getCodeByURL($url){

	if(strstr($url, 'v=')){
		$queryString = parse_url($url, PHP_URL_QUERY);
		parse_str($queryString, $params);
		$code = $params['v'];
	}else{
		$video_explode = explode('/', $url);
		$code = $video_explode[sizeof($video_explode)-1];
	}

	return $code;
}


function getThumbnailByVideoURL($code, $type = '', $size = ''){
	$thumbnail_url = '';
	if($type =='youtube'){
		$thumbnail_url = "https://i3.ytimg.com/vi/".$code."/".$size.".jpg";
	}elseif($type =='vimeo'){
		$thumbnail_info = unserialize(file_get_contents("https://vimeo.com/api/v2/video/$code.php"));
		if(!empty($thumbnail_info)){
			$thumbnail_url = $thumbnail_info[0]['thumbnail_'.$size];
		}
	}
	return $thumbnail_url;
}

function getGameVideoHtml($game_id=''){

$Articles = new Articles();
$games = $Articles->getPostsByType('game');

$post_type = 'game';

if(empty($game_id)){
	$selected_game = get_posts(array(
			'showposts' => 1,
			'order' => 'asc',
			'orderby' => 'menu_order',
			'post_type' => $post_type,
			'post_status'      => 'publish',
			'meta_query' => array(
				array(
					'key'   => 'game_type',
					'value' => 'mobile'
				)
			)
		)
	);
	if(!empty($selected_game)) {
		$selected_game = $selected_game[0];
	}

}else{
	// game detail page
	$selected_game = get_post($game_id);
	$game_type = get_field('game_type', $game_id);

	if($game_type!='mobile'){
		
		?>
		<section class="mascoteers-game vr-gear-main">
			<div class="container">
				<div class="row">
					<div class="game-info flex-order-2">
						<span class="text-center">Playing any of The Mascoteers game?</span>
						<h4 class="h4 text-center"><span>Be the first to know about our future games</span>follow us on social media</h4>
						<div class="row social-like">
							<div class="col-sm-6 social-list">
								<ul>
									<li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
									<li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
									<li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
									<li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
								</ul>
							</div>
							<div class="col-sm-6 like-section">
			
								<div id="fb-root"></div>
								<script>(function(d, s, id) {
										var js, fjs = d.getElementsByTagName(s)[0];
										if (d.getElementById(id)) return;
										js = d.createElement(s); js.id = id;
										js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=268439510204075";
										fjs.parentNode.insertBefore(js, fjs);
									}(document, 'script', 'facebook-jssdk'));</script>
			
								<div class="fb-page" data-href="https://www.facebook.com/TheMascoteers" data-tabs="timeline"  data-height="316" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/TheMascoteers" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/TheMascoteers">The Mascoteers</a></blockquote></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php

		return '';
	}
}

if(empty($selected_game)) return '';


$games = get_posts(array(
		'showposts' => -1,
		'order' => 'asc',
		'orderby' => 'menu_order',
		//'exclude'          => $selected_game->ID,
		'post_type' => $post_type,
		'post_status'      => 'publish',
		'meta_query' => array(
			array(
				'key'   => 'game_type',
				'value' => 'mobile'
			)
		)
	)
);

?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<section class="mascoteers-game">
	<div class="container">
		<div class="row">


			<div class="col-md-5 flex-container-order video-container iPad-container">

				<?php
				if(!empty($selected_game)) {
					$selected_game_youtube_link = get_field('youtube_link', $selected_game->ID);
					$iphone_video_link = get_field('youtube_link_small', $selected_game->ID);
					$game_stores = $Articles->getGameStoreShort($selected_game->ID);

					//$share_link = get_permalink($selected_game);
					$share_title = $selected_game->post_title;

					$type = getTypeByURL($selected_game_youtube_link);
					$code = getCodeByURL($selected_game_youtube_link);

					$iphone_type = getTypeByURL($iphone_video_link);
					$iphone_code = getCodeByURL($iphone_video_link);

					/*if($type == 'youtube'){
						$size = 0;
					}else{
						$size = 'large';
					}
					$thumbnail_url = getThumbnailByVideoURL($code, $type, $size);*/


					?>
					<div class="game-header flex-order-1">
						<div class="game-share-container">
							<span class="share"  onclick="toggleshare('share-button')"><span>Share <?php echo $share_title; ?> game play</span></span>
							<div class="share-icons-list" id="share-button" style="display: none; width: 100px; right: inherit;">
								<a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $selected_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-facebook"></i></a>
								<a class="google-plus" href="https://plus.google.com/share?url= <?php echo $selected_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-google-plus"></i></a>
								<a class="twitter" href="http://twitter.com/home?status= <?php echo $selected_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-twitter"></i></a>
							</div>
						</div>


						<div class="toggle-button" <?php if(wp_is_mobile() && !strpos($_SERVER['HTTP_USER_AGENT'],"iPad")){ echo 'style="display:none"';} ?>>
							<label class="iPhone-link device-link">iPhone</label><div class="switch"> <div id="device-slider" style="width: 50px"></div> </div>  <label class="iPad-link device-link">iPad</label>
						</div>
					</div>

					<div id="game-display-container" class="flex-order-2">
						<div class="device" data-video_id="<?php echo $selected_game->ID;?>" data-ipad_video_code="<?php echo $code;?>"  data-ipad_video_type="<?php echo $type;?>" data-iphone_video_code="<?php echo $iphone_code;?>" data-iphone_video_type="<?php echo $iphone_type;?>">
							<?php
							if(!empty($selected_game_youtube_link)>0){
								//echo   "<img class='device-img ajax-thumbnail' src='' data-ipad_video_code='".$code."' data-ipad_video_type='".$type."'/><span class='play-button' rel='".$selected_game->ID."'></span>";

								?>
								<img class="device-img ajax-thumbnail"
									 data-ipad_video_code="<?php echo $code; ?>"
									 data-ipad_video_type="<?php echo $type; ?>"
									 data-iphone_video_code="<?php echo $iphone_code; ?>"
									 data-iphone_video_type="<?php echo $iphone_type; ?>"
									  src=""
									 title="<?php echo $selected_game->post_title; ?>"/>
								<span class="play-button"
									  rel="<?php echo $selected_game->ID; ?>"
									  data-ipad_video_code="<?php echo $code; ?>"
									  data-ipad_video_type="<?php echo $type; ?>"
									  data-iphone_video_code="<?php echo $iphone_code; ?>"
									  data-iphone_video_type="<?php echo $iphone_type; ?>">
								</span>
								<?php
							}
							?>
						</div>
						<div class="share-buttons-group">
							<?php echo $game_stores; ?>
						</div>
					</div>

				<?php } ?>
			</div>

			<div class="col-md-7 flex-container-order">
				<div class="game-info flex-order-2">
					<span class="text-center">Playing any of The Mascoteers game?</span>
					<h4 class="h4 text-center"><span>Be the first to know about our future games</span>follow us on social media</h4>
					<div class="row social-like">
						<div class="col-sm-6 social-list">
							<ul>
								<li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
								<li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
								<li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
								<li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
							</ul>
						</div>
						<div class="col-sm-6 like-section">

							<div id="fb-root"></div>
							<script>(function(d, s, id) {
									var js, fjs = d.getElementsByTagName(s)[0];
									if (d.getElementById(id)) return;
									js = d.createElement(s); js.id = id;
									js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=268439510204075";
									fjs.parentNode.insertBefore(js, fjs);
								}(document, 'script', 'facebook-jssdk'));</script>

							<div class="fb-page" data-href="https://www.facebook.com/TheMascoteers" data-tabs="timeline"  data-height="316" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/TheMascoteers" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/TheMascoteers">The Mascoteers</a></blockquote></div>
						</div>
					</div>
				</div>

				<div class="carosal-tab video-carousel flex-order-1">
					<ul>
						<?php
						if(!empty($games)){
							foreach ($games as $game){
								$youtube_link = get_field('youtube_link', $game->ID);
								$youtube_link_small = get_field('youtube_link_small', $game->ID);

								$type = getTypeByURL($youtube_link);
								$code = getCodeByURL($youtube_link);


								$type_small = getTypeByURL($youtube_link_small);
								$code_small = getCodeByURL($youtube_link_small);

								/*if($type == 'youtube'){
									$size = 0;
								}else{
									$size = 'large';
								}
								$thumbnail_url = getThumbnailByVideoURL($code, $type, $size);*/

								if(!empty($youtube_link)){
									//if($type=='vimeo') {
										?>
										<li class="<?php echo $game->post_name; ?>">
											<img class="ajax-thumbnail"
												 data-ipad_video_code="<?php echo $code; ?>"
												 data-ipad_video_type="<?php echo $type; ?>"
												 data-iphone_video_code="<?php echo $code_small; ?>"
												 data-iphone_video_type="<?php echo $type_small; ?>"
												 src=""
												 title="<?php echo $game->post_title; ?>" style="width:124px"/>
											<span class="play-button"
												  rel="<?php echo $game->ID; ?>"
												  data-ipad_video_code="<?php echo $code; ?>"
												  data-ipad_video_type="<?php echo $type; ?>"
												  data-iphone_video_code="<?php echo $code_small; ?>"
												  data-iphone_video_type="<?php echo $type_small; ?>">
											</span>
										</li>
										<?php
									//}
								}
							}
						}
						?>
					</ul>
				</div> <!-- carosal-tab -->
			</div>
		</div>
	</div>
</section>


<?php
	wp_enqueue_script('jquery-ui', 'https://code.jquery.com/ui/1.12.0/jquery-ui.js', array('jquery'), false, true);
?>


<script>
	jQuery(document).ready(function ($) {

		$.browser.device = (/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()));

		//console.log(navigator.userAgent);
		$(".ajax-thumbnail").each(function (key, value) {
			var param = $(this);
			var type = param.attr('data-ipad_video_type');
			var code = param.attr('data-ipad_video_code');
			loadVideoThumb(param, type, code);
		});


		$(".play-button").live('click',function () {

			var $game_container = jQuery('#game-display-container');
			var $game_share_container = jQuery('.game-share-container');
			$game_container.find('.device').html('<img class="loading" src="'+directory_url+'/images/loading.gif">');

			$(".play-button").removeClass('pause');
			$(this).addClass('pause');

			var value = $( "#device-slider" ).slider( "value" );

			var device = 'iPhone';
			var $width = 275;
			var $iframe_height = 390;
			var $iPad_width = 443;
			if(value==2){
				device = 'iPad';
				var $width = 443;
				var $iframe_height = 390;
			}

			$game_container.find('.device').attr('data-video_id', $(this).attr('rel'));
			$game_container.find('.device').attr('data-ipad_video_code', $(this).attr('data-ipad_video_code'));
			$game_container.find('.device').attr('data-ipad_video_type', $(this).attr('data-ipad_video_type'));

			$game_container.find('.device').attr('data-iphone_video_code', $(this).attr('data-iphone_video_code'));
			$game_container.find('.device').attr('data-iphone_video_type', $(this).attr('data-iphone_video_type'));

			var video_id = $game_container.find('.device').attr('data-video_id');

			jQuery.ajax({
				type: 'POST',
				url: ajax_url,
				data: {
					"action": "load_video",
					"id": video_id,
					'device': device
				},
				async: false,
				success: function(response){

					obj = JSON.parse(response);
					$game_container.find(".share-buttons-group").html(obj.game_stores);
					
					$iframe = '';
					if(obj.type=='youtube'){
						$iframe = '<iframe src="https://www.youtube.com/embed/'+obj.video_code+'?rel=0&autoplay=1" width="'+$width+'" frameborder="0" allowfullscreen></iframe>';
					}else{
						$iframe = '<iframe src="https://player.vimeo.com/video/'+obj.video_code+'?autoplay=1" width="'+$width+'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
					}

					$game_container.find('.device').html($iframe);
					$game_share_container.find(".share-icons-list").html(obj.share_html);
					$game_share_container.find(".share").html('Share '+obj.game_title+' game play');
				}
			});

		});

		var isMobile = false;
		var slider_value = 2;
		//remove iPad
		if( /Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
			isMobile = true;
			slider_value = 1;
		}

		$( "#device-slider" ).slider({
			animate: "slow",
			max: 2,
			min: 1,
			step: 1,
			value:slider_value,
			slide: function(event, ui) {

				var $device = 'iPhone';
				var $width = 275;
				if(ui.value==2){
					$device = 'iPad';
					var $width = 443;
				}

				ajaxLoadThumbnail($device);

				changeDevice($device, $width);
			}
		});


		$(".device-link").click(function () {

			var $set_value = 2;
			if($(this).hasClass('iPhone-link')){
				$set_value = 1;
			}

			var $device = 'iPhone';
			var $width = 275;
			if($set_value==2){
				$device = 'iPad';
				var $width = 443;
			}

			$( "#device-slider" ).slider('value', $set_value);
			ajaxLoadThumbnail($device);
			changeDevice($device, $width);

		});

		function changeDevice($device, $width) {

			$( ".device").removeClass('iPhone iPad');
			$( ".device").addClass($device);
			$( ".video-container").removeClass('iPhone-container iPad-container');
			$( ".video-container").addClass($device+'-container');
			jQuery("#game-display-container .device, #game-display-container .device-img").animate({ width: $width }, 150);
			jQuery("#game-display-container iframe").animate({ width: $width }, 150);
		}

		function ajaxLoadThumbnail($device) {

			var selected_device = 'iPad';
			if($device=='iPhone'){
				selected_device = 'iphone';
			}

			var $game_container = jQuery('#game-display-container');
			var video_id = $game_container.find('.device').attr('data-video_id');
			var type = $game_container.find('.device').attr('data-'+selected_device+'_video_type');
			var code = $game_container.find('.device').attr('data-'+selected_device+'_video_code');

			if(type == 'vimeo') {
				jQuery.ajax({
					type: 'GET',
					url: '//vimeo.com/api/v2/video/' + code + '.json',
					jsonp: 'callback',
					dataType: 'jsonp',
					success: function (data) {
						var thumbnail_src = data[0].thumbnail_large;

						$game_container.find('.device').html("<img class='device-img' src='"+thumbnail_src+"'/><span class='play-button' rel='"+video_id+"'></span>");
					}
				});
			}else if(type == 'youtube'){
				var thumbnail_src = "//i3.ytimg.com/vi/"+code+"/0.jpg";
				$game_container.find('.device').html("<img class='device-img' src='"+thumbnail_src+"'/><span class='play-button' rel='"+video_id+"'></span>");
			}
		}

		if(isMobile) {
			$(".device").addClass('iPhone');
		}else{
			$(".device").addClass('iPad');
		}

	});
</script>

<?php
}

add_filter('get_archives_link', 'archive_count_no_brackets');
function archive_count_no_brackets($links) {
	$links = str_replace('</a>&nbsp;(', '</a>&nbsp;', $links);
	$links = str_replace(')', '', $links);
	return $links;
}


add_action('pre_get_posts','set_posts_per_page');

function set_posts_per_page( $query ) {
	if ( ! is_admin() && is_post_type_archive('game')) {
		$query->set('posts_per_page', 2);
	}

	if ( ! is_admin() && is_post_type_archive('device_game')) {

		$query->set('posts_per_page', 500);
		
		$user_agent= user_agent();

		$meta_key = '';
		if($user_agent=='android'){
			$meta_key = 'android_link';
		}elseif ($user_agent=='ios'){
			$meta_key = 'ios_link';
		}

		$meta_key_arr[] = array(
			'key'=>'show_on_games',
			'value'=>1,
			'compare'=>'=',
		);
		if(!empty($meta_key)) {
			$meta_key_arr['relation'] = 'AND';
			$meta_key_arr[] = array(
				'key' => $meta_key,
				'value' => '',
				'compare' => '!='
			);
		}

		$query->set('orderby', 'menu_order title');
		$query->set('order', 'ASC');
		$query->set('meta_query', $meta_key_arr);
	}
}

function user_agent(){
	$iPod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");
	$iPhone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
	$iPad = strpos($_SERVER['HTTP_USER_AGENT'],"iPad");
	$amazon = strpos($_SERVER['HTTP_USER_AGENT'],"Silk");
	$android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
	if($iPad||$iPhone||$iPod){
		return 'ios';
	}else if($amazon){
		return 'amazon';
	}else if($android){
		return 'android';
	}else{
		return 'pc';
	}
}

function addHttp($url) {
	if (!preg_match("@^https?://@i", $url) && !preg_match("@^ftps?://@i", $url)) {
		$url = "http://" . $url;
	}
	return $url;
}
