<?php get_header(); ?>

<section class="banner-content"><?php echo do_shortcode('[home_banner]'); ?></section>
<script>
    jQuery("#home-banner, #home-banner .slide").height(jQuery(window).height());
</script>
<?php
$post = get_page_by_path('about-the-mascoteers');
if (!empty($post)) {
?>
<section class="about-mascoteers">
    <div class="split-block">
        <div class="mascoteers-brand">
            <?php
            if (has_post_thumbnail( $post->ID )){
                echo wp_get_attachment_image(get_post_thumbnail_id($post->ID), 'full');
            }
            ?>
        </div>
    </div>
    <div class="split-block">
        <h2><?php echo $post->post_title; ?></h2>
        <div class="intro-text gray-skin custom-scroll" id="about-mascoteers-content2">
            <?php  if(get_field('short_description', $post->ID)){  ?>
                <div class="short-description"><?php the_field('short_description', $post->ID) ?></div>
                <div class="full-description" style="display: none"><?php echo apply_filters('the_content', $post->post_content); ?></div>
                <a href="#" title="Read More" class="read-more read-more-less read"><span>+</span>Read More</a>
            <?php }else{ ?>
                <div class="full-description"><?php echo apply_filters('the_content', $post->post_content); ?></div>
            <?php } ?>
        </div>
    </div>
</section>
<?php } ?>

<section class="social-share">
    <ul>
        <li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
        <li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
        <li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
        <li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
    </ul>
</section>

<section class="our-game">
    <div class="container">
        <h2 class="h2">Our game</h2>
        <p class="text-center intro-head">Download &amp; Play our fun filled, challenging &amp; addictive mobile games created to deliver you an unique engaging experience with all the latest smartphones out there!</p>
        <?php echo do_shortcode('[game_slider]'); ?>
    </div>
</section>

<section class="game-details">
    <?php echo do_shortcode('[game_text_slider]'); ?>
</section>

<?php getGameVideoHtml(); ?>
<?php get_footer(); ?>
