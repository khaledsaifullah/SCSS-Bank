<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<section class="innerpage-conent">
	<div class="container">
 			<article class="page type-page status-publish hentry">
				<header class="entry-header">
					<h1 class="entry-title">404 Error Page</h1>
				</header>
				<!-- .entry-header -->

				<div class="entry-content">
					<div class="error-page">
						<h1>O<span>ops</span>!</h1>
						<h2>404 Error </h2>
						<p>Oh Dear! We can't find the page you were looking for. Isn't that annoying? Sorry for the inconvenience.</p>
					</div>
				</div>
			</article>
 	</div>
</section>
<?php get_footer(); ?>
