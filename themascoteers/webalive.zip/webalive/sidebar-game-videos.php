<?php
$Articles = new Articles();
$games = $Articles->getPostsByType('game');
?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<section class="mascoteers-game">
	<div class="container">
		<div class="row">


			<div class="col-sm-5">

				<?php
				if(!empty($games)) {
					$first_game = $games[0];
					$first_game_youtube_link = get_field('youtube_link', $first_game->ID);
					$code = getCodeByURL($first_game_youtube_link);
					$game_stores = $Articles->getGameStore($first_game->ID);

					$share_link = get_permalink($first_game);
					$share_title = $first_game->post_title;

					$thumb = "https://i3.ytimg.com/vi/".$code."/0.jpg";


					?>
					<div class="game-header">
						<div class="game-share-container">
							<span class="share"  onclick="toggleshare('share-button')">Share <?php echo $share_title; ?> game play</span>
							<div class="share-icons-list" id="share-button" style="display: none; width: 100px; right: inherit;">
								<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $first_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-facebook"></i></a>
								<a href="https://plus.google.com/share?url= <?php echo $first_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-google-plus"></i></a>
								<a href="http://twitter.com/home?status= <?php echo $first_game_youtube_link; ?>&title=<?php echo $share_title; ?>" target="_blank" class="js--popup"><i class="fa fa-twitter"></i></a>
							</div>
						</div>

						<div class="toggle-button">
							<label>iPhone</label><div class="switch"> <div id="device-slider" style="width: 50px"></div> </div>  <label>iPad</label>
						</div>
					</div>

					<div id="game-display-container">
						<div class="device">
							<?php
							if(strlen($code)>0){
								echo   "<img src='https://i3.ytimg.com/vi/".$code."/0.jpg'/><span class='play-button' rel='".$first_game->ID."'></span>";
							}
							?>
						</div>
						<div class="share-buttons-group">
							<?php echo $game_stores; ?>
						</div>
					</div>

				<?php } ?>
			</div>

			<div class="col-sm-7">
				<div class="game-info">
					<span class="text-center">Playing any of the Mascoteers Game</span>
					<h4 class="h4 text-center"><span>Be the first to know about our future games</span>Follow us on social media</h4>
					<div class="row social-like">
						<div class="col-sm-6 social-list">
							<ul>
								<li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
								<li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
								<li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
								<li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
							</ul>
						</div>
						<div class="col-sm-6 like-section">

							<div id="fb-root"></div>
							<script>(function(d, s, id) {
									var js, fjs = d.getElementsByTagName(s)[0];
									if (d.getElementById(id)) return;
									js = d.createElement(s); js.id = id;
									js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=268439510204075";
									fjs.parentNode.insertBefore(js, fjs);
								}(document, 'script', 'facebook-jssdk'));</script>

							<div class="fb-page" data-href="https://www.facebook.com/TheMascoteers" data-tabs="timeline"  data-height="316" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="false"><blockquote cite="https://www.facebook.com/TheMascoteers" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/TheMascoteers">The Mascoteers</a></blockquote></div>
						</div>
					</div>
				</div>

				<div class="carosal-tab video-carousel">
					<ul>
						<?php
						if(!empty($games)){
							foreach ($games as $game){
								$youtube_link = get_field('youtube_link', $game->ID);
								$code = getCodeByURL($youtube_link);
								if(strlen($code)>0){
									?>
									<li><img src="https://i3.ytimg.com/vi/<?php echo $code; ?>/0.jpg" style="width:124px"/><span class="play-button" rel="<?php echo $game->ID; ?>"></span></li>
									<?php
								}
							}
						}
						?>
					</ul>
				</div> <!-- carosal-tab -->
			</div>
		</div>
	</div>
</section>


<?php
wp_enqueue_script('jquery-ui', 'https://code.jquery.com/ui/1.12.0/jquery-ui.js', array('jquery'), false, true);
wp_enqueue_script('jquery.custom-scrollbar', get_template_directory_uri().'/additional-lib/jquery.cusotm.scrollbar/jquery.custom-scrollbar.js', array('jquery'), false, true);
?>


<script>
	jQuery(document).ready(function ($) {

		$(".play-button").click(function () {

			jQuery('#game-display-container .device').html('<img class="loading" src="'+directory_url+'/images/loading.gif">');

			$(".play-button").removeClass('pause');
			$(this).addClass('pause');

			var value = $( "#device-slider" ).slider( "value" );

			var device = 'iPhone';
			var $width = 200;
			var $height = 400;
			if(value==2){
				device = 'iPad';
				var $width = 370;
				var $height = 400;
			}

			var video_id = $(this).attr('rel');

			jQuery.ajax({
				type: 'POST',
				url: ajax_url,
				data: {
					"action": "load_video",
					"id":video_id
				},
				async: false,
				success: function(response){
					obj = JSON.parse(response);
					$("#game-display-container .share-buttons-group").html(obj.game_stores);

					jQuery('#game-display-container .device').html('<iframe width="'+$width+'" height="'+$height+'" src="https://www.youtube.com/embed/'+obj.video_code+'?rel=0&autoplay=1" frameborder="0" allowfullscreen></iframe>');
					$(".game-share-container .share-icons-list").html(obj.share_html);
					$(".game-share-container .share").html('Share '+obj.game_title+' game play');
				}
			});

		});


		$( "#device-slider" ).slider({
			animate: "slow",
			max: 2,
			min: 1,
			step: 1,
			value:2,
			slide: function(event, ui) {

				var device = 'iPhone';
				var $width = 200;
				var $height = 400;
				if(ui.value==2){
					device = 'iPad';
					var $width = 370;
					var $height = 400;
				}

				$( ".device").removeClass('iPhone iPad');
				$( ".device").addClass(device);
				jQuery('#game-display-container .device').width($width);
				jQuery('#game-display-container iframe').width($width);
			}
		});
		$( ".device").addClass('iPad');

	});
</script>
