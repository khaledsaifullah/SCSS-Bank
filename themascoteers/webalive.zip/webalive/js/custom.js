jQuery(document).ready(function ($) {

    $(".menu-container").height($(window).height());
    var $right = jQuery(".menu-container").css('right');
    $(".menu-link").click(function () {
        if($(this).hasClass('show')) {
            $pixel = "0px";
        }else{
            $pixel =$right;
        }
        $(".menu-container").animate({"right": $pixel}, "slow");

        $(".menu-link").toggleClass('show');
    });
    $(".menu-close").click(function () {
        $(".menu-link").trigger('click');
    })


    $(".read-more-less").click(function (e) {
        e.preventDefault();
        $(this).parent().find('.short-description').slideToggle('down');
        $(this).parent().find('.full-description').slideToggle('down');

        /*if($(this).hasClass('read')){

            $('.short-description').css('display', 'none');
            $('.full-description').css('display', 'block');

            $('.full-description').slimScroll({
                height: '130px',
                //width: '400px',
                alwaysVisible: true
            });
        }else{
            $(".full-description").slimScroll({destroy: true});
            $('.full-description').css('display', 'none');
            $('.short-description').css('display', 'block');
        }*/

        $(this).toggleClass("read");
        var $read_more_text = '<span>-</span>Read Less';
        if($(this).hasClass('read')){
            var $read_more_text = '<span>+</span>Read More';
        }
        $(this).html($read_more_text);
    });
    
    //Hide search form on click some selectors
    $(document).click(function(e) {
        if ($(e.target).is('.search-toggle, .search-toggle *, .search-box-wrapper, .search-box-wrapper *')) {
            return;
        }
        else{
            var search_wrapper_element = $( '.search-box-wrapper' );
            if((search_wrapper_element.is(':visible'))) {
                search_wrapper_element.addClass( 'hide' );
                $( '.search-toggle' ).removeClass( 'active' );
            }
        }
    });

    $(".box").hide();
    $('.toggle-menu').click(function(e){
        e.preventDefault();
        $(this).toggleClass('active');
        $(".box").stop(true,true).slideToggle();
    });
    
    banner();
});

function toggleshare(id) {
    var div = document.getElementById(id);
    div.style.display = div.style.display == "none" ? "block" : "none";
}

function banner() {

    if(jQuery('#home-banner').length>0) {
        jQuery('#home-banner').bxSlider({
            auto: true,
            controls:true,
            pager:false,
            preventDefaultSwipeY: false
        });
    }

  /*  if(jQuery('#blog-slider').length>0) {
        var $slider = jQuery('#blog-slider').bxSlider({
            auto: false,
            controls:true,
            pager:false,
            mode:'vertical',
            minSlides:2,
            maxSlides:2,
            moveSlides:1,
            nextSelector: '#slider-next',
            prevSelector: '#slider-prev',
            nextText: '>',
            prevText: '<',
            onSlideAfter:function($slideElement, oldIndex, newIndex){
                //console.log(jQuery($slideElement).find(".images"))
                jQuery("#featured-blog-slider .images").html(jQuery($slideElement).find(".images").html());
                jQuery("#featured-blog-slider .description-area").html(jQuery($slideElement).find(".new-desc").html());
            }
        });
    }*/

    if(jQuery('#featured-blog-slider').length>0) {
        var $slider = jQuery('#featured-blog-slider').bxSlider({
            auto: false,
            controls:(jQuery("#featured-blog-slider .item").length > 1) ? true: false,
            pager:false,
            nextSelector: '#slider-next',
            prevSelector: '#slider-prev',
            nextText: '>',
            prevText: '<',
            preventDefaultSwipeY: false
        });
    }
    
    if(jQuery('#game-slider').length>0) {
       jQuery('#game-slider').bxSlider({
            auto: true,
            controls:true,
            pager:false,
            minSlides: 1,
            maxSlides: 2,
            slideWidth: 585,
            slideMargin: 20,
           preventDefaultSwipeY: false
        });
    }
    
    if(jQuery('#game-text-slider').length>0) {
        jQuery('#game-text-slider').bxSlider({
            auto: false,
            controls:true,
            pager:false,
            preventDefaultSwipeY: false
        });
    }

    if(jQuery('.game-gallery').length>0) {
        jQuery('.game-gallery').bxSlider({
            auto: true,
            controls:true,
            pager:false,
            minSlides: 1,
            maxSlides: 4,
            slideWidth: 280,
            slideMargin: 15,
            preventDefaultSwipeY: false
        });
    }

    if(jQuery('.video-carousel ul').length>0) {
        jQuery('.video-carousel ul').bxSlider({
            auto: true,
            controls:true,
            pager:false,
            minSlides: 1,
            maxSlides: 4,
            slideWidth:125,
            slideMargin: 25,
            preventDefaultSwipeY: false
        });
    }
}

function loadVideoThumb(param, type, code) {

    if(type == 'vimeo') {
        jQuery.ajax({
            type: 'GET',
            url: '//vimeo.com/api/v2/video/' + code + '.json',
            jsonp: 'callback',
            dataType: 'jsonp',
            success: function (data) {
                var thumbnail_src = data[0].thumbnail_large;
                //console.log(thumbnail_src);
                param.attr("src", thumbnail_src);
            }
        });
    }else if(type == 'youtube'){
        var thumbnail_src = "//i3.ytimg.com/vi/"+code+"/0.jpg";
        param.attr("src", thumbnail_src);
    }
}


function playVideo($param, $code, $type, $width, $height){

    $iframe = '';
    if($type=='youtube'){
        $iframe = '<iframe width="'+$width+'" height="'+$height+'" src="https://www.youtube.com/embed/'+$code+'?rel=0&autoplay=1" frameborder="0" allowfullscreen></iframe>';
    }else if($type == 'vimeo'){
        $iframe = '<iframe src="https://player.vimeo.com/video/'+$code+'?autoplay=1" width="'+$width+'" height="'+$height+'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
    }

    jQuery($param).parent().html($iframe);
}

