<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php twentysixteen_post_thumbnail(); ?>
	<div class="entry-content-blog">
		<div class="date-area">
			<span class="day"> <?php the_time('d'); ?> </span>
			<span class="month">  <?php the_time('M'); ?> </span>
		</div>
		<header class="entry-header">
			<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
				<span class="sticky-post"><?php _e( 'Featured', 'twentysixteen' ); ?></span>
			<?php endif; ?>

			<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
		</header><!-- .entry-header -->
		<?php twentysixteen_excerpt(); ?>
		<footer class="entry-footer">
			<!--<div class="entry-footer-left">By <p><?php /*echo get_the_author();*/?></p></div>-->
			<div class="entry-footer-right"><?php twentysixteen_entry_meta(); ?></div>
		</footer><!-- .entry-footer -->
		<div class="entry-content">
			<?php
			/* translators: %s: Name of current post */
			/*the_content( sprintf(
				__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'twentysixteen' ),
				get_the_title()
			) );*/

			the_field('short_description');

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
			?>
		</div><!-- .entry-content -->


		<div class="extra-links">
			<a href="<?php the_permalink(); ?>">Read More</a>
			<?php
			echo getGameLink($post->ID);
			?>
		</div>

		<!--<div class="share-links product-share icon-share" rel="<?php /*the_ID(); */?>"><i class="fa fa-share-alt"></i>
			<div class="share-icons-list post-id-<?php /*the_ID();*/?>" style="display: none">
				<a href="https://www.facebook.com/sharer/sharer.php?u=<?php /*echo get_the_permalink(); */?>" target="_blank" class="js--popup"><i class="fa fa-facebook"></i></a>
				<a href="https://plus.google.com/share?url=<?php /*echo get_the_permalink(); */?>" target="_blank" class="js--popup"><i class="fa fa-google-plus"></i></a>
				<a href="http://twitter.com/home?status=<?php /*echo get_the_permalink(); */?>" target="_blank" class="js--popup"><i class="fa fa-twitter"></i></a>
			</div>
		</div>-->

	</div>
	<section class="social-share">
		<ul>
			<li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
			<li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
			<li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
			<li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
		</ul>
	</section><!-- /social-share -->
</article><!-- #post-## -->
