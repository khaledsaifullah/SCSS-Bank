<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php twentysixteen_post_thumbnail(); ?>
	<div class="entry-content-blog">
		<div class="date-area">
			<span class="day"> <?php the_time('d'); ?> </span>
			<span class="month">  <?php the_time('M'); ?> </span>
		</div>
		<header class="entry-header">
			<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
		</header><!-- .entry-header -->
		<?php twentysixteen_excerpt(); ?>
		<footer class="entry-footer">
			<!--<div class="entry-footer-left">By <p><?php /*echo get_the_author();*/?></p></div>-->
			<div class="entry-footer-right"><?php twentysixteen_entry_meta(); ?></div>
		</footer><!-- .entry-footer -->
		<div class="entry-content">
			<?php
			the_content();

			wp_link_pages( array(
				'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentysixteen' ) . '</span>',
				'after'       => '</div>',
				'link_before' => '<span>',
				'link_after'  => '</span>',
				'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'twentysixteen' ) . ' </span>%',
				'separator'   => '<span class="screen-reader-text">, </span>',
			) );
			?>
		</div><!-- .entry-content -->
		<div class="extra-links">
			<?php
			echo getGameLink($post->ID);
			?>
		</div>
	</div>
	<section class="social-share">
		<ul>
			<li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i>Follow us on Twitter</a></li>
			<li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i>Like us on Facebook</a></li>
			<li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i>Subscribe to our Channel</a></li>
			<li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i>Follow us on Instagram</a></li>
		</ul>
	</section><!-- /social-share -->
</article><!-- #post-## -->
