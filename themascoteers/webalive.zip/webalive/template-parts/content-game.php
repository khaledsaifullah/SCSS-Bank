<?php
/**
 * The template part for displaying content
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

$Articles = new Articles();
$image = get_field('image', $post->ID);
$logo = get_field('logo', $post->ID);
$game_stores = $Articles->getGameStore($post->ID);

$facebook = get_field('facebook', $post->ID);

$youtube_link = get_field('youtube_link', $post->ID);
$youtube_link_small = get_field('listing_page_small_video_link', $post->ID);
$code = getCodeByURL($youtube_link);
$code_small = getCodeByURL($youtube_link_small);

$type = getTypeByURL($youtube_link);
$code = getCodeByURL($youtube_link);

$type_small = getTypeByURL($youtube_link_small);
$code_small = getCodeByURL($youtube_link_small);


$game_type = get_field('game_type', $post->ID);

?>
<section class="game-container">

<div class="container">
	<div class="row">
		<div class="col-sm-12 game-top-banner">
			<div class="game-banner">
				<img class="img-responsive" src="<?php echo $image['url'] ?>" alt="">
				<a href="<?php the_permalink(); ?>" class="visit-button">visit <?php the_title(); ?> page <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
				<?php echo $game_stores; ?>
			</div>
		</div>
	</div>
	<div class="row">

		<?php if($game_type=='mobile'){ ?>
			<div class="col-sm-5">
		<?php }else{ ?>
			<div class="col-sm-12 vr-game">
		<?php } ?>


			<div class="game-content">
				<header class="">
					<div class="thumb-photo"><img class="img-responsive" src="<?php echo $logo['url']; ?>" alt=""></div>
					<a class="like-fb" href="<?php echo $facebook; ?>" target="_blank"><img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/images/like-fb.jpg" alt=""></a>
				</header>
				<div class="intro-text">
					<?php

						$content = apply_filters('the_content', $post->post_content);
						echo readMore($content, $word_limit = 60);
					?>

				</div>
			</div>

			<?php if($game_type=='mobile'){ ?>
				<?php if(!empty($youtube_link_small)){ ?>
				<div class="small-video">
					<img class="img-responsive ajax-thumbnail" src="<?php //echo $thumbnail_url_small; ?>" data-ipad_video_type="<?php echo $type_small; ?>" data-ipad_video_code="<?php echo $code_small; ?>"/>
					<span class="play-button" onclick="playVideo(this, '<?php echo $code_small ?>','<?php echo $type_small ?>', 470, 353)"></span>
				</div>
				<?php } ?>
			<?php } ?>

		</div>
		<?php if($game_type=='mobile'){ ?>

			<div class="col-sm-7">
				<div class="video">
					<?php if(!empty($youtube_link)){ ?>
					<img class="img-responsive ajax-thumbnail" src="<?php //echo $thumbnail_url; ?>" data-ipad_video_type="<?php echo $type; ?>" data-ipad_video_code="<?php echo $code; ?>" />
					<span class="play-button" onclick="playVideo(this, '<?php echo $code ?>', '<?php echo $type ?>', 670, 640)"></span>
					<?php } ?>
				</div>
			</div>

		<?php } ?>
	</div>
</div>

</section>

<?php if($game_type=='mobile'){ ?>
<script>

	jQuery(document).ready(function ($) {
			$(".ajax-thumbnail").each(function (key, value) {
				var param = $(this);
				var type = param.attr('data-ipad_video_type');
				var code = param.attr('data-ipad_video_code');
				loadVideoThumb(param, type, code);
			});
	});
</script>
<?php } ?>

<style>
	.addthis_toolbox{
		display:none
	}
</style>