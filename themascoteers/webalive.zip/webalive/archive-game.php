<title>Android and iOS Games by The Mascoteers</title>
<meta name="description" content="Download & Play our fun filled, challenging & addictive games created to deliver you an unique engaging experience with all the latest smartphones out there!"/>

<?php if(!isset($_POST['action']) || $_POST['action']!='ajax'){ ?>

<?php get_header(); ?>

	<header class="page-header">
		<h1 class="page-title">Our Games</h1>
	</header><!-- .page-header -->


	<div id="game_container">


<?php } ?>

		<?php if ( have_posts() ) : ?>




			<?php

				global $paged;
				global $wp_query;
				global $query_string;
				$wp_query->max_num_pages;
				$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
				query_posts($query_string.'&posts_per_page=2&orderby=menu_order title&order=ASC');


				// Start the Loop.
				while ( have_posts() ) : the_post();

					/*
					 * Include the Post-Format-specific template for the content.
					 * If you want to override this in a child theme, then include a file
					 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
					 */
					get_template_part( 'template-parts/content', 'game');

				// End the loop.
				endwhile;

				if($wp_query->max_num_pages > $paged):
					?>
					<button class="btn btn-primary btn-sm loadMoreBlogBtn"  transition_speed="2000" onclick="javascript:loadMoreBlog(this,'<?php echo get_next_posts_page_link();?>',<?php echo $paged;?>)">Load More</button>
					<span class="loader-img"></span>
					<?php
				endif;
		
			// If no content, include the "No posts found" template.
			else :
				get_template_part( 'template-parts/content', 'none' );

			endif;

			?>


<?php if(!isset($_POST['action']) || $_POST['action']!='ajax'){ ?>
	</div>

	<script>
		var loock = false;
		var load_data = true;
		function loadMoreBlog(elem,url,page) {

			jQuery(".loader-img").html('<img src="'+directory_url+'/images/ajax-loader.gif">');

			 load_data = false;
			if(loock){
				return;
			}
			loock = true;
			elem.parentNode.removeChild(elem);
			var data = {
				action: 'ajax',
				page: page
			}

			jQuery.post(url, data)
				.done(function (response) {
					jQuery("#game_container").append(response).appendTo(".content").fadeIn("slow")
					loock = false;
					load_data = true;
					jQuery(".loader-img").html('');
					jQuery(".loader-img:not(:last)").remove();
				})
				.fail(
					function(jqXHR, textStatus, errorThrown) {
						loock = false;
					}
				);
		};

		jQuery(window).scroll(function($) {
			if(jQuery(window).scrollTop() + jQuery(window).height() == jQuery(document).height() && load_data==true) {
				jQuery('.loadMoreBlogBtn').trigger('click');
			}
		});

	</script>




<?php get_footer(); ?>
<?php } ?>