<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<?php get_header();

while ( have_posts() ) : the_post();

	$presskit_link = get_field('presskit_link', $post->ID);
	$facebook_link = get_field('facebook', $post->ID);

	$youtube_link = get_field('youtube_link_small', $post->ID);
	$game_type = get_field('game_type', $post->ID);
	$type_small = getTypeByURL($youtube_link);
	$code_small = getCodeByURL($youtube_link);

	/*if($type == 'youtube'){
		$size = 0;
	}else{
		$size = 'large';
	}*/

	//$thumbnail_url = getThumbnailByVideoURL($code, $type, $size);

	$image = get_field('image', $post->ID);
	$game_stores = $Articles->getGameStore($post->ID);
?>

<section class="game-banner-section">
		<?php
			if(!empty($image)) {
				?>
				<img class="img-responsive" src="<?php echo $image['url'] ?>" alt="<?php the_title(); ?>">
				<?php
			}
		?>
	<?php echo $game_stores; ?>
</section>
<section class="game-details-top box-container <?php if($game_type!='mobile'){ echo 'vr-game-detail'; } ?>">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 game-details-toppart">
				<div class="row">

					<?php if($game_type=='mobile'){ ?>
						<div class="col-sm-5 col-md-3">
							<div class="smart-phone">
								<img class="ajax-thumbnail" src="<?php //echo $thumbnail_url; ?>"  data-ipad_video_type="<?php echo $type_small; ?>" data-ipad_video_code="<?php echo $code_small; ?>"/>
								<span class="play-button" onclick="playVideo(this, '<?php echo $code_small ?>','<?php echo $type_small ?>',226,396)"></span>
							</div>
						</div>
					<?php } ?>

					<?php if($game_type=='mobile'){ ?>
					<div class="col-sm-7 col-md-9">
					<?php }else{ ?>
						<div class="col-sm-12 col-md-12">
					<?php } ?>
						<div class="center-align">
							<div class="center-align-container">
								<header>
									<div class="row game-name-row">

										<div class="col-sm-3 col-md-2 icon-box-gd">
											<div class="images">
												<?php
												$logo = get_field('logo', $post->ID);
												if(!empty($logo)){
													?>
													<img src="<?php echo $logo['url']; ?>" alt="">
												<?php } ?>
											</div>
										</div>
										<div class="col-sm-9 col-md-6 content-box-gd">
											<div class="info">
												<h2><?php the_title(); ?></h2>
												<p class="bold"><?php the_field('slogan', $post->ID); ?></p>
											</div>
										</div>
										<div class="col-sm-12 col-md-4">
											<div class="vertical-bottom ">
												<a class="square-btn" href="<?php echo home_url('/presskit/'.$presskit_link.'/'); ?>" title=""><?php the_title(); ?> presskit</a>
											</div>
										</div>
									</div>
								</header><!-- /header -->
								<?php
									the_content();
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-12">
				<div class="row fb-game-detail-top">
					<div class="col-sm-12">
						<div class="facebook-game-details">
							<a href="<?php echo $facebook_link?>" target="_blank"><img border="0" alt="facebook" src="<?php echo get_template_directory_uri(); ?>/images/facebook-like.png" /></a>
							<h4>This is all about our Gamers!</h4>
							<p>Your opinion matters! Please let us know what you think about <?php the_title(); ?> ran in to a problem, wish to offer a suggesion for improvement or for just about anything simply drop us a line in facebook and we promise that we will look at it!</p>
						</div>
					</div>
				</div>

				<div class="row fb-game-detail-bottom">
					<div class="col-sm-9">
						<div class="facebook-game-comment">
						<?php
						if(!empty($facebook_link)){
							?>
							<div id="fb-root"></div>
							<script>(function(d, s, id) {
									var js, fjs = d.getElementsByTagName(s)[0];
									if (d.getElementById(id)) return;
									js = d.createElement(s); js.id = id;
									js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=268439510204075";
									fjs.parentNode.insertBefore(js, fjs);
								}(document, 'script', 'facebook-jssdk'));</script>

							<div class="fb-comments" data-href="<?php echo $facebook_link; ?>" data-width="100%" data-numposts="5"></div>

						<?php } ?>
						</div>
					</div>
					<div class="col-sm-3">
						<div class="facebook-game-likebox">
							<?php
							if(!empty($facebook_link)){
								?>
								<div id="fb-root"></div>
								<script>(function(d, s, id) {
										var js, fjs = d.getElementsByTagName(s)[0];
										if (d.getElementById(id)) return;
										js = d.createElement(s); js.id = id;
										js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.7&appId=268439510204075";
										fjs.parentNode.insertBefore(js, fjs);
									}(document, 'script', 'facebook-jssdk'));</script>

								<div class="fb-page" data-href="<?php echo $facebook_link; ?>" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true">
									<blockquote cite="<?php echo $facebook_link; ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo $facebook_link; ?>"><?php the_title(); ?></a></blockquote>
								</div>

							<?php } ?>
						</div>
					</div>
				</div>
				
				
				
				
				
			</div>
		</div>
	</div>
</section>
<?php
	
	echo getGallery($post->ID);
	getGamePostsHtml($post->post_name);
 	getGameVideoHtml($post->ID);

endwhile;

get_footer();
