<title>Games by The Mascoteers</title>

<script type="text/javascript">
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-67696543-1', 'auto');
ga('send', 'pageview');
</script>

<!-- Facebook Pixel Code -->
<script> 
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod? 
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n; 
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, 
document,'script','https://connect.facebook.net/en_US/fbevents.js'); 
fbq('init', '1208283882585202'); 
fbq('track', 'PageView'); 
</script>
<noscript><img height="1" width="1" style="display:none" 
src="https://www.facebook.com/tr?id=1208283882585202&ev=PageView&noscript=1" 
/></noscript>
<!-- DO NOT MODIFY -->
<!-- End Facebook Pixel Code -->

<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Raleway:400,600" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1">
<section class="games-list">
	<div class="container">
		<div class="row">

		<?php if ( have_posts() ) : ?>

			<?php

			$user_agent= user_agent();
			$meta_key = 'facebook_link';
			$download_text = '';

			if($user_agent=='android'){
				$meta_key = 'android_link';
				$download_text = 'Click to Download the Games you like from Play Store';
			}elseif ($user_agent=='ios'){
				$meta_key = 'ios_link';
				$download_text = 'Click to Download the Games you like from App Store';
			}

			if(!empty($download_text)) {
				echo '<h2 class="download-text">'.$download_text.'</h2>';
			}


			while ( have_posts() ) : the_post();

				if(!empty($meta_key)) {
					$link = get_field($meta_key, $post->ID);
				}else{
					$link = 'javascript:void(0)';
				}

				?>

				<div class="col-md-3 col-xs-3">
					<div class="single-cam-link">
						<?php
							if (has_post_thumbnail( $post->ID )) {
								?>
								<a href="<?php echo $link; ?>"
onclick="ga('send', 'event', '<?php the_title(); ?>', '<?php echo user_agent(); ?>', 'Christmas Campaign');return true;"
>
									<?php echo wp_get_attachment_image(get_post_thumbnail_id($post->ID), array(160, 160)); ?>
								</a>
								<?php
							}
						?>
						<h4><a href="<?php echo $link;?>"
onclick="ga('send', 'event', '<?php the_title(); ?>', '<?php echo user_agent(); ?>', 'Christmas Campaign');return true;"
><?php the_title(); ?></a></h4>
					</div>
				</div>
				<?php
			endwhile;
		else :
			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
		</div>
		<div class="btns-row">
			<a href="https://www.themascoteers.com" class="visit-btn">Visit Our Website</a>
			<a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo home_url('/games') ?>&title=Games by The Mascoteers&description=Download the games free on your iOS or Android Devices!&picture=<?php echo get_option('games_share_image') ?>"target="_blank" class="js--popup share-btn">Share This Page</a>
		</div>
	</div>
</section>

<script>
	/* social popup window */
	/* http://andy-carter.com/site/js/ui.min.js */
	function click(n,o,t){for(var i=document.getElementsByTagName(n),e=new RegExp("\\b"+o+"\\b","g"),p=0;p<i.length;p++)i[p].className.match(e)&&t.apply(i[p])}function popupWindow(){this.onclick=function(){var n=this.getAttribute("href");return window.open(n,"popup","height=350,width=400,toolbar=no,location=no,status=no,menubar=no"),!1}}window.onload=function(){click("a","js--popup",popupWindow)};

</script>


<style>
	*{
		box-sizing: border-box;
	}
	body{
		margin: 0;
		padding: 0;
		-webkit-text-size-adjust: 100%;
		background: #fff;
	}
	.games-list{
		padding-top: 10px;
		padding-bottom: 10px;
	}
	.row {
		margin-right: -15px;
		margin-left: -15px;
		overflow: hidden;
	}
	.container{
		width: 100%;
		max-width: 1024px;
		padding-right: 15px;
		padding-left: 15px;
		margin-right: auto;
		margin-left: auto;
		box-sizing: border-box;
		overflow: hidden;

	}
	h2{
		text-align: center;
		padding-bottom: 25px;
		font-family: 'Raleway';
		font-size: 18px;
	}
	.single-cam-link{
		text-align: center;
	}
	.single-cam-link a{
		text-decoration: none;
		color: #202b39;
	}
	.single-cam-link img {
		max-width: 100%;
		width: 120px;
		height: auto;
		border-radius: 20px;
	}
	.single-cam-link h4{
		font-size: 15px;
		margin-top: 12px;
		font-family: 'Raleway', sans-serif;
		font-weight: 600;
	}
	.single-cam-link h4 a{
		font-size: 1em;
	}
	.btns-row{
		text-align: center;
		margin-top: 20px;
		margin-bottom: 20px;
	}
	.btns-row a{
		display: inline-block;
		text-decoration: none;
		font-family: 'Lato';
	}
	.visit-btn{
		margin-right: 4px;
		color: #202b39;
		font-size: 13px;
		text-align: center;
		text-transform: uppercase;
		font-weight: 400;
		font-family: 'Lato';
		border-width: 2px;
		border-style: solid;
		border-color: #202b39;
		padding: 12px 25px;
		box-shadow: 0 0 0 0 #202b39 inset;
		transition: all 0.4s ease 0s;
		background: #fff;
	}
	.visit-btn:hover{
		background: #202b39;
		border-color: #202b39;
		color: #fff;
	}
	.share-btn{
		margin-right: 4px;
		color: #fff;
		font-size: 13px;
		text-align: center;
		text-transform: uppercase;
		font-weight: 400;
		font-family: 'Lato';
		border-width: 2px;
		border-style: solid;
		border-color: #d01931;
		padding: 12px 25px;
		box-shadow: 0 0 0 0 #d01931 inset;
		transition: all 0.4s ease 0s;
		background: #d01931;
	}
	.share-btn:hover{
		background: #f22940;
		border-color: #f22940;
	}
	.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
		position: relative;
		min-height: 1px;
		padding-right: 15px;
		padding-left: 15px;

	}
	.col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9 {
		float: left;

	}
	.col-xs-3 {
		width: 25%;
	}
	@media (min-width: 768px){
		.col-sm-4 {
			width: 33.33333333%;
		}
	}
	@media (min-width: 992px){
		.col-md-3 {
			width: 25%;
		}
	}


	@media all and (max-width: 767px) {
		.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9{
			padding-left: 10px;
			padding-right: 10px;
		}
		.single-cam-link h4{
			font-size: 12px;
		}
	}
	@media all and (max-width: 480px) {
		h2{
			font-size: 14px;
			padding: 0 10px 15px;
		}
		.btns-row a{
			width: 100%;
			padding: 10px 15px;
		}
		.visit-btn{
			margin-bottom: 10px;
			border-width: 2px;
		}
		.single-cam-link {
			height: auto!important;
		}
		.single-cam-link h4{
			margin-top: 5px;
			font-size: 10px;
			margin-bottom: 5px;
		}
		.single-cam-link h4 a{
			font-size: 1em;
			line-height: 1;
			height: 21px;
			display: block;
		}
		.single-cam-link img {
			max-width: 70px!important;
			border-radius: 8px!important;
			width: 100%;
		}
		.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9{
			padding-left: 6px;
			padding-right: 6px;
		}
	}
</style>

