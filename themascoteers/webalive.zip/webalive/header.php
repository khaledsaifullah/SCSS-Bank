<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
     <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
 <?php endif; ?>

 <?php
 define("BOOTSTRAP", 1);
 define("BXSLIDER", 1);
 define("COLORBOX", 1);
 ?>


     <!-- FONT
     –––––––––––––––––––––––––––––––––––––––––––––––––– -->
     <link href='https://fonts.googleapis.com/css?family=Raleway:100,400,500,700,800,900|Open+Sans:300,300italic,400,400italic,600|Lato:400,300,700' rel='stylesheet' type='text/css'>
     <!--<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>-->
    <!-- CSS
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/css/animate.min.css" rel="stylesheet">
    
    <?php wp_head(); ?>
    <link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo get_template_directory_uri(); ?>/developer.css" rel="stylesheet">

</head>

<body <?php body_class(); ?>>
<!--start: header -->
<header class="header">
    <div class="header-content">
            <div class="company-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">The Mascoteers</a></div>
            <a href="javascript:void(0)" class="menu-link show">Menu</a>
    </div>
</header>

<div class="menu-container">
    <div class="main-nav">
        <?php
        if ( has_nav_menu( 'primary' ) ) :
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_class'     => 'primary-menu',
            ) );
           endif;
        ?>
    </div>
    <a href="javascript:void(0)" class="menu-close">Close</a>
</div>