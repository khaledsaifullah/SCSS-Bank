<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <span class="copyright"><?php echo get_option('copyright') ?></span>
                <nav class="footer-nav"> <?php wp_nav_menu(array('menu'=>'footer')) ?></nav><!-- /footer-nav -->
                <div class="social">
                    <ul>
                        <li class="facebook"><a href="<?php echo get_option('facebook') ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li class="twitter"><a href="<?php echo get_option('twitter') ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li class="youtube"><a href="<?php echo get_option('youtube') ?>" target="_blank"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
                        <li class="instagram"><a href="<?php echo get_option('instagram') ?>" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                    </ul>
                </div><!-- /social -->
            </div>
            <div class="col-sm-4">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="office-address">
                            <div class="map"><img src="<?php echo get_template_directory_uri(); ?>/images/australia-map.png" alt=""></div>
                            <div class="addr">
                                <h6>Australia Office</h6>
                                <address><?php echo get_option('australia_office_address') ?></address>
                            </div>
                        </div><!-- /office-address -->
                    </div>
                <!--    <div class="col-sm-6">
                        <div class="office-address">
                            <div class="map"><img src="<?php /*echo get_template_directory_uri(); */?>/images/bangladesh-map.png" alt=""></div>
                            <div class="addr">
                                <h6>Bangladesh Office</h6>
                                <address><?php /*echo get_option('bangladesh_office_address') */?> </address>
                            </div>
                        </div><!-- /office-address 
                    </div>-->
                </div>
            </div>
        </div>
    </div>
</footer>



<?php wp_footer(); ?>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-67696543-1', 'auto');

    ga('require', 'displayfeatures');
    ga('send', 'pageview');

</script>

<!-- Facebook Pixel Code -->
<script>
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
        n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
        document,'script','https://connect.facebook.net/en_US/fbevents.js');

    fbq('init', '1171752926189450');
    fbq('track', "PageView");
    fbq('track', 'ViewContent');
</script>
<noscript><img height="1" width="1" style="display:none"
               src="https://www.facebook.com/tr?id=1171752926189450&ev=PageView&noscript=1"
    /></noscript>
<!-- End Facebook Pixel Code -->

</body>
</html>
