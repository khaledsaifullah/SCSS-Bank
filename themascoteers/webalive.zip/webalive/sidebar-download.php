<!DOCTYPE html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="Shortcut Icon" type="image/x-icon" href="https://www.themascoteers.com/wp-content/themes/webalive/images/favicon.ico" />
</head>
<body>

<div class="d-con-container">

    <?php
    $game_slug = $wp_query->query_vars['game_slug'];
    $the_slug = preg_replace('(^_*)', '',$game_slug);
    $args=array(
        'name'           => $the_slug,
        'post_type'      => 'device_game',
        'post_status'    => 'publish',
        'posts_per_page' => 1
    );
    $posts = get_posts( $args );
    if(!empty($posts)){

    $post = $posts[0];

    $user_agent= user_agent();

    $arr = array(
        'android'=>array(
            'title'=>'Google Play',
            'meta_key'=>'android_link',
            'app_icon'=>'google-play-btn.png'
        ),
        'ios'=>array(
            'title'=>'App Store',
            'meta_key'=>'ios_link',
            'app_icon'=>'app-store-btn.png'
        ),
        'amazon'=>array(
            'title'=>'Amazon',
            'meta_key'=>'amazon_link',
            'app_icon'=>'amazon.png'
        )
    );

    $redirect_link = '';
    if($user_agent=='amazon'){
        $redirect_link = get_field('amazon_link', $post->ID);
        if(!empty($redirect_link)){
            unset($arr['ios']);
            unset($arr['android']);
        }else{
            $redirect_link = get_field('android_link', $post->ID);
            unset($arr['ios']);
            unset($arr['amazon']);
        }
    }elseif($user_agent=='android'){
        $redirect_link = get_field('android_link', $post->ID);
        unset($arr['ios']);
        unset($arr['amazon']);
    }elseif ($user_agent=='ios'){
        $redirect_link = get_field('ios_link', $post->ID);
        unset($arr['android']);
        unset($arr['amazon']);
    }

    if(!empty($redirect_link)){
        ?>
        <script type="text/javascript">
            window.location.href = '<?php echo $redirect_link; ?>';
        </script>
        <?php
    }

    if(has_post_thumbnail($post->ID)){
        echo wp_get_attachment_image(get_post_thumbnail_id());
    }

    ?>

    <title><?php echo $post->post_title; ?> - Download</title>
    <p> If you are not redirected automatically, please select your device</p>
    <div class="sh-links">
        <?php
        foreach ($arr as $app){
            $link = trim(get_field($app['meta_key'], $post->ID));
            if(!empty($link)) {
                $get_link = addHttp($link);
                echo '<a href="' . $get_link . '" target="_blank"> <img src="' . get_template_directory_uri() . '/images/' . $app['app_icon'] . '" alt="' . $app['title'] . '"> </a>';
            }
        }
        ?>
        <a href="<?php echo addHttp(get_field('facebook_link', $post->ID)); ?>" target="_blank" class="others_btn">Others</a>

    </div>
</div>
<style>
    * {
        box-sizing: border-box;
    }
    html, body {
        text-align: center;
        margin: 0;
        padding: 5% 0 0 0;
        font-family: 'Raleway', sans-serif;
        line-height: 1.37;

    }
    img{
        height: auto;
        width: auto;
    }
    a{
        text-decoration: none;
        vertical-align: middle;
    }
    .d-con-container{
        padding: 0 15px;
    }
    .d-con-container img{
        width: 160px;
        border-radius: 10px;
        max-width: 100%;
    }
    .sh-links a {
        display: inline-block;
        margin: 0 7px 10px;
    }
    .sh-links a img{
        max-width: 133px;
        border-radius: 0;
        width: 100%;
    }
    .sh-links a.others_btn{
        background: #000;
        padding: 9px 45px;
        border-radius: 4px;
        color: #fff;
        margin-left: 3px;
    }
    .sh-links a.others_btn:hover{
        background: #d01830;
    }
    @media only screen and (max-width: 480px) {
        body{font-size: 14px}
        .sh-links a.others_btn{
            margin-left: 5px;
        }
        .d-con-container img{
            width: 124px;
        }
    }
</style>
<?php

}
?>
</body>
</html>