<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php if ( is_singular() && pings_open( get_queried_object() ) ) : ?>
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <?php endif; ?>

    <?php
    define("BOOTSTRAP", 1);
    define("BXSLIDER", 1);
    define("COLORBOX", 1);
    ?>


    <!-- FONT
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:100,400,500,700,800,900|Open+Sans:300,300italic,400,400italic,600|Lato:400,300,700' rel='stylesheet' type='text/css'>
    <!--<link href='https://fonts.googleapis.com/css?family=Open+Sans:300,300italic,400,400italic,600' rel='stylesheet' type='text/css'>
   <link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'>-->
    <!-- CSS
    –––––––––––––––––––––––––––––––––––––––––––––––––– -->
    <link href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo get_template_directory_uri(); ?>/css/animate.min.css" rel="stylesheet">

    <?php wp_head(); ?>
    <link href="<?php echo get_template_directory_uri(); ?>/css/style.css" rel="stylesheet">

    <link href="<?php echo get_template_directory_uri(); ?>/developer.css" rel="stylesheet">
</head>

<body <?php body_class(); ?>>
<!--start: header -->
<header class="header mobile-game-development">
    <div class="header-content">
        <div class="company-logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">The Mascoteers</a></div>
        <a href="javascript:void(0)" class="menu-link show">Menu</a>
    </div>
</header>

<div class="menu-container">
    <div class="main-nav">
        <?php
        if ( has_nav_menu( 'primary' ) ) :
            wp_nav_menu( array(
                'theme_location' => 'primary',
                'menu_class'     => 'primary-menu',
            ) );
        endif;
        ?>
    </div>
    <a href="javascript:void(0)" class="menu-close">Close</a>
</div>







<div class="mobile-game-caption">
    <h2>Are you looking for a mobile game<br> development company?</h2>
    <p>If you have a great mobile game idea and want to translate that into a top performing product, we are here to help. We don’t just design and develop excellent mobile games; we know how to monetise your game using ads and convert regular players into paying customers.</p>
    <a href="<?php echo esc_url( home_url( '/contact-us' ) ); ?>" class="mobile-contact-link">Contact us</a>
</div>


<section class="our-service-area">
    <h2 class="service-block-title">Our Services</h2>
    <div  class="our-service-content">
        <div class="service-block android-game-development">
            <h4>Android<br />game development</h4>
            <p>Our experienced Android developers can build entertaining robust games from scratch or take your existing games to a new level. We develop games for Android-powered phones, tablets, and other smart devices. Our deep understanding of mobile game engines, design principles, and the Android marketplace ensure that your game will be both entertaining and financially successful. The Mascoteers team has already developed several worldwide hits like 360 Degree, Circlify, and Dropple for Android devices.       </p>
        </div>
        <div class="service-block ios-game-development">
            <h4>iOS<br />game development</h4>
            <p>We develop highly interactive and engaging games for iOS devices. With a long experience in releasing successful games for iPhone and iPad, our team can turn any creative idea into an exciting mobile game. Whether you want to build a financially successful title or just want to venture into Apple’s App Store for the first time, we can turn your game concept into a success story. We also develop cross-platform games that run on both iOS and Android.  </p>
        </div>
        <div class="service-block arvr-game-development">
            <h4>AR/VR <br />game development</h4>
            <p>Augmented and virtual reality is on the rise. As more and more people get AR/VR devices, these games are going to rule this industry in the near future. If you are ready to launch your AR/VR game in Android or iOS, we can gladly help you with end-to-end design and development. With several successful VR games under our belt, we will fuse your ideas with our creativity to produce an engaging augmented gaming experience.  </p>
        </div>

    </div>
</section>


<section class="our-game">
    <div class="container">
        <h2 class="h2">Our game</h2>
        <p class="text-center intro-head">Download &amp; Play our fun filled, challenging &amp; addictive mobile games created to deliver you an unique engaging experience with all the latest smartphones out there!</p>
        <?php echo do_shortcode('[game_slider]'); ?>
    </div>
</section>

<section class="why-choose-us">
    <h2 class="why-choose-title">Why choose us</h2>
    <div  class="why-choose-content">
        <div class="why-choose-block">
            <p> Mascoteers has developed numerous fun-filled, challenging and addictive mobile games. Many of our games have been featured in Google Play Store. Our developers maintain the same level of standard and quality control that you would expect from the top game studios in the industry.</p>
        </div>
        <div class="why-choose-block">
            <p>Our designers are well known for their innovative concepts, versatility, and uniqueness, while adhering to the user-friendly design principles. We know how to monetise your game using ads and set up the perfect freemium model without undermining the player experience.</p>
        </div>
        <div class="why-choose-block">
            <p>When you work with us, you’ll get a dedicated project manager who will report the progress to you and collect your feedbacks at each step. We are committed to providing seamless communication and ongoing customer support for each of our clients.</p>
        </div>
        <div class="why-choose-block">
            <p>We provide expert consultation and technical support regarding game monetisation. If you are not sure how to get the most out of your game, our team can help you come up with the right pricing strategy, develop an appropriate pricing model and find the best way to get the most out of your game.  </p>
        </div>
    </div>
</section>

<section class="submit-your-game">
    <h2>Want to discuss your next game development project with us?<br>We’ll be happy to hear your thoughts!</h2>
    <a href="<?php echo esc_url( home_url( '/contact-us' ) ); ?>" class="submit-your-game-btn">Contact Us</a>
</section>

<?php get_footer(); ?>
