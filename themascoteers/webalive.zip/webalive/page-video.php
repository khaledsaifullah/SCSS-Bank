<?php get_header();


$url= 'http://vimeo.com/189752064';
//$url= 'https://youtu.be/wByp5d4IutM';
//$url = 'https://www.youtube.com/watch?v=SbGFYjCbpRs';

$type = getTypeByURL($url);
$code = getCodeByURL($url);

$size ='';
if($type == 'youtube'){
    $size = 0;
}else{
    $size = 'large';
}


/*$data = file_get_contents("https://www.vimeo.com/api/v2/video/".$code.".json");
$thumbnail_info = json_decode($data);
echo '<pre>';
print_r($thumbnail_info);
echo '</pre>';*/

?>

    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            video_id = '189752064';
            $.ajax({
                type: 'GET',
                url: '//vimeo.com/api/v2/video/' + video_id + '.json',
                jsonp: 'callback',
                dataType: 'jsonp',
                success: function (data) {
                    console.log(data[0]);
                    var thumbnail_src = data[0].thumbnail_large;
                    /*var thumbnail_src = data[0].thumbnail_medium;
                    var thumbnail_src = data[0].thumbnail_small;*/
                    $('#thumb_wrapper').append('<img src="' + thumbnail_src + '"/>');
                }
            });
        });
    </script>

    <div id="thumb_wrapper"></div>

<?php


 get_footer();
