(function($) {
    jQuery(document).ready(function(){
        /*jQuery('.datetimepicker').datepicker({format: 'dd/mm/yy',startDate:'0d', autoclose: true});
        jQuery('.date-search-field').datepicker({format: 'yyyy-mm-dd', autoclose: true});*/

        jQuery('.datetimepicker').datepicker({dateFormat: 'dd/mm/yy',minDate:0});
        jQuery('.datetimepickerfull').datepicker({dateFormat: 'dd/mm/yy'});

        var date = new Date();
        date.setDate(date.getDate() + 7);
        var dateMsg = date.getDate()+'/'+ (date.getMonth()+1) +'/'+date.getFullYear();

        jQuery('.datetimepickernext7').datepicker({
            dateFormat: 'dd/mm/yy',
            minDate:0,
           // defaultDate: date,
        });



        jQuery('.date-search-field').datepicker({dateFormat: 'yy-mm-dd'});
        jQuery('.timepicker').timepicker({ 'step': 5,'timeFormat': 'h:i A' });

        jQuery('.input-group-addon').on('click',function(){
           jQuery(this).siblings('input').focus();
        });

        jQuery('.search_input').on('change',function(){
           jQuery(this).parents('form').submit();
        });

        jQuery.validator.addMethod("requiredIf", function(value, element, params) {
            var $ = jQuery;
            if($(params[0]).length){
                if ($.trim($(params[0]).val()) != "") {
                    return $.trim($(element).val()) != "";
                }
            }
            return  true;
        }, jQuery.validator.format("This field is required."));

        jQuery.validator.addMethod("requireOne", function(value, element,param) {
            if($(param).length){
                return true;
            }
            return false;
        }, "Please select at least one option");

        jQuery.validator.addMethod("requiredUpload", function(value, element, params) {
            var $ = jQuery;
            if(element.files.length > 0){
                return true;
            }
            return  false;
        }, jQuery.validator.format("File upload is required."));


    });
}(jQuery));



function update_upload_status(element,value){
    if(jQuery("#"+element).length){
        jQuery("#"+element).val(value);

        jQuery("#"+element).closest('form').validate().element(jQuery("#"+element));
    }
}