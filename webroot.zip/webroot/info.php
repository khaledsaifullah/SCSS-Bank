<?php
/**
 * Created by PhpStorm.
 * User: bakar
 * Date: 18/05/15
 * Time: 4:58 PM
 */


//echo $now = strtotime('now'),'<br>';
//echo $seven_days = strtotime('now')+604800,'<br>'; // next 7 days

phpinfo();
echo date('d-m-Y g:i a').'<br>';
echo date('d-m-Y g:i a',strtotime('now')),'<br>';
$utc = strtotime('now');
date_default_timezone_set("Australia/Victoria");
echo date('d-m-Y g:i a').'<br>';
echo date('d-m-Y g:i a',strtotime('now'));
$au_now = strtotime('now');

//echo $au_now-$utc;
//phpinfo();
